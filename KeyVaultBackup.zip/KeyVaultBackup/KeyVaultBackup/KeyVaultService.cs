﻿using Microsoft.Azure;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;
using Microsoft.Azure.Services.AppAuthentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyVaultBackup
{
     public class KeyVaultService
    {
        private static readonly string keyVaultUrl = CloudConfigurationManager.GetSetting("vaultURL");
        //private static readonly string RestorekeyVaultUrl = CloudConfigurationManager.GetSetting("RestorevaultURL");

        private readonly AzureServiceTokenProvider azureServiceTokenProvider;
        public KeyVaultService()
        {
            azureServiceTokenProvider = new AzureServiceTokenProvider();
        }
        public async Task<List<string>> GetKeyAsync(string secret)
        {
            try
            {
                using (var client = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback)))
                {
                    var keyList = new List<string>();
                    var keyResult = await client.GetSecretAsync("");
                    //foreach (var item in keyResult)
                    //{
                    //    keyList.Add(item.Identifier.ToString());
                    //}
                    return keyList;
                }
            }
            catch(Exception ex)
            {
                return new List<string>();
            }

        }
        public async Task<BackupKeyResult> BackupKeyAsync(string key)
        {
                using (var client = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback)))
                {
                    var keyResult = await client.BackupKeyAsync(keyVaultUrl,key);

                return keyResult;
                }

        }





    }
}

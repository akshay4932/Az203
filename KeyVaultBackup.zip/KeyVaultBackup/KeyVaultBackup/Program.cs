﻿using Microsoft.Azure;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;
using Microsoft.Azure.Services.AppAuthentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyVaultBackup
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Key Vault Backup Operation");
            var keyVaultService = new KeyVaultService();
            var storageService = new StorageService();
            var keyList = new List<string>();
            keyList = keyVaultService.GetKeyAsync().Result;
            foreach (var key in keyList)
            {
                var keyName = key.Split('/').Last();
                Console.WriteLine("Starting Backup of {0}",keyName);
                BackupKeyResult keyresult = keyVaultService.BackupKeyAsync(keyName).Result;
                Console.WriteLine("Uploading Backup of {0} to Blob Storage", keyName);
                storageService.UploadToBlob(keyresult.Value, keyName);
            }
            Console.WriteLine("All Upload Successful");
            Console.ReadLine();
        }

    }
}

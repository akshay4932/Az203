﻿using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyVaultBackup
{
    class StorageService
    {
        public void UploadToBlob(byte[] key, string keyName)
        {
            String strorageconn = CloudConfigurationManager.GetSetting("StorageConnectionString");
            CloudStorageAccount storageacc = CloudStorageAccount.Parse(strorageconn);

            CloudBlobClient blobClient = storageacc.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("keybackup");

            container.CreateIfNotExists();
            var Date = DateTime.UtcNow.ToString("dd-MMM-yyyy");
            var blobReference = Date + "\\" + keyName;
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(blobReference);


            blockBlob.UploadFromByteArrayAsync(key, 0, key.Count());

        }
        public byte[] DownloadFromBlob(string keyName)
        {
            byte[] key = new byte[0];

            String strorageconn = CloudConfigurationManager.GetSetting("StorageConnectionString");
            CloudStorageAccount storageacc = CloudStorageAccount.Parse(strorageconn);

            CloudBlobClient blobClient = storageacc.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("keybackup");

            container.CreateIfNotExists();

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(keyName);
            using (var ms = new MemoryStream())
            {
                blockBlob.DownloadToStream(ms);
                key = ms.ToArray();
            }
            return key;

        }
    }
}

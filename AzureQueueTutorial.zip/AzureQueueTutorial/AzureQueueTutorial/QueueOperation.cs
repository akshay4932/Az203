﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureQueueTutorial
{
    public class AzureQueueOperation
    {
        public async Task CreateQueue()
        {
            StorageConnection conn = new StorageConnection();
            // Retrieve storage account from connection string.
            CloudStorageAccount storageAccount = conn.storageAccount;

            // Create the queue client.
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            // Retrieve a reference to a queue.
            CloudQueue queue = queueClient.GetQueueReference("myqueue");

            // Create the queue if it doesn't already exist.
            if(await queue.CreateIfNotExistsAsync())
            {
                Console.WriteLine("queue {0} created" , queue.Name);
            }
            else
            {
                Console.WriteLine("queue {0} exists", queue.Name);
            }
        }

        public async Task AddMessageToQueue(string message)
        {
            StorageConnection conn = new StorageConnection();
            // Retrieve storage account from connection string.
            CloudStorageAccount storageAccount = conn.storageAccount;

            // Create the queue client.
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            // Retrieve a reference to a queue.
            CloudQueue queue = queueClient.GetQueueReference("myqueue");

            CloudQueueMessage queuemessage = new CloudQueueMessage(message);
            await queue.AddMessageAsync(queuemessage);
        }

        public async Task RetriveMessage()
        {
            StorageConnection conn = new StorageConnection();
            // Retrieve storage account from connection string.
            CloudStorageAccount storageAccount = conn.storageAccount;

            // Create the queue client.
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            // Retrieve a reference to a queue.
            CloudQueue queue = queueClient.GetQueueReference("myqueue");

            CloudQueueMessage retrievedMessage = await queue.GetMessageAsync();
            Console.WriteLine("Retrieved message with content '{0}'", retrievedMessage.AsString);

            await queue.DeleteMessageAsync(retrievedMessage);
            Console.WriteLine("Deleted message");
        }

        public async Task RetriveBulkMessageWithLock()
        {
            // Retrieve storage account from connection string.
            StorageConnection conn = new StorageConnection();
            // Retrieve storage account from connection string.
            CloudStorageAccount storageAccount = conn.storageAccount;

            // Create the queue client.
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            // Retrieve a reference to a queue.
            CloudQueue queue = queueClient.GetQueueReference("myqueue");

            foreach (CloudQueueMessage message in await queue.GetMessagesAsync(20,TimeSpan.FromSeconds(50),null,null))
            {
                // Process all messages in less than 5 seconds, deleting each message after processing.
                Console.WriteLine("Message {0} processed",message);
                queue.DeleteMessage(message);
            }
        }
    }
}

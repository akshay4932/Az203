﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureQueueTutorial
{
    class Program
    {
        static void Main(string[] args)
        {
            AzureQueueOperation queueOperation = new AzureQueueOperation();
            //queueOperation.CreateQueue().GetAwaiter().GetResult();
            //queueOperation.AddMessageToQueue("mymessage").GetAwaiter().GetResult();
            //queueOperation.RetriveMessage().GetAwaiter().GetResult();
            queueOperation.RetriveBulkMessageWithLock().GetAwaiter().GetResult();

        }
    }
}

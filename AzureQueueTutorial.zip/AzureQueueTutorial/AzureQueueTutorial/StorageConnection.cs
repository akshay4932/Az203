﻿using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureQueueTutorial
{
    public class StorageConnection
    {
        public CloudStorageAccount storageAccount;
        public StorageConnection()
        {
            storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("ConnStr"));
        }
    }
}

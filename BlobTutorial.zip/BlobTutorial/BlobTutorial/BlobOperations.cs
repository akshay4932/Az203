﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlobTutorial
{
    public class BlobOperations
    {

        public async Task UploadToBlob()
        {
            string imageToUpload = @"D:\Akshay\single-vm-diagram.png";

            string blobReference = imageToUpload.Split('\\').Last();

            string containerName = "imagessoumya";

            CloudStorageAccount StorageAccount = StorageConnection.GetAzureConnection();

            CloudBlobClient blobClient = StorageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference(containerName);

            await container.CreateIfNotExistsAsync();

            await container.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });

            CloudBlockBlob blob = container.GetBlockBlobReference(blobReference);

            await blob.UploadFromFileAsync(imageToUpload);

            string uri = blob.Uri.ToString();

            Console.WriteLine("Blob Uplaoded successfully uri is {0}",uri);

        }

        public async Task UploadToBlobHierarchy()
        {
            string imageToUpload = @"D:\Akshay\Network.png";

            string blobReference = "azuretutorial\\akshay\\test\\" + imageToUpload.Split('\\').Last();

            CloudStorageAccount StorageAccount = StorageConnection.GetAzureConnection();

            CloudBlobClient blobClient = StorageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("images2");

            await container.CreateIfNotExistsAsync();

            await container.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });

            CloudBlockBlob blob = container.GetBlockBlobReference(blobReference);

            await blob.UploadFromFileAsync(imageToUpload);

        }

        public async Task ListBlobs()
        {
            CloudStorageAccount StorageAccount = StorageConnection.GetAzureConnection();

            CloudBlobClient blobClient = StorageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("imagessoumya");

            BlobContinuationToken blobContinuationToken = null;
            do
            {
                var blobs = await container.ListBlobsSegmentedAsync(blobContinuationToken);
                blobContinuationToken = blobs.ContinuationToken;
                foreach (IListBlobItem item in blobs.Results)
                {
                    Console.WriteLine(item.Uri);
                }
            } while (blobContinuationToken != null);
        }

        public async Task DownloadBlob()
        {
            string imageToDownload = @"D:\Akshay\Network.png";

            string blobReference = imageToDownload.Split('\\').Last();

            CloudStorageAccount StorageAccount = StorageConnection.GetAzureConnection();

            CloudBlobClient blobClient = StorageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("images");

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(blobReference);

            await blockBlob.DownloadToFileAsync(imageToDownload, FileMode.Create);


        }

        public async Task BlobCopy()
        {
            CloudStorageAccount StorageAccount = null;
            string sourceblobReference = "Network.png";

            string destinationblobReference = "NetworkCopy.png";
            try
            {
                StorageAccount = StorageConnection.GetAzureConnection();
            }
            catch
            {
                Console.WriteLine("Azure storage connection cannot be established");
            }
            CloudBlobClient blobClient = StorageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("images");

            container.CreateIfNotExists();

            CloudBlobContainer container2 = blobClient.GetContainerReference("images-copy");

            container2.CreateIfNotExists();

            CloudBlockBlob sourceblockBlob = container.GetBlockBlobReference(sourceblobReference);

            CloudBlockBlob destinationblockBlob = container2.GetBlockBlobReference(destinationblobReference);

            await destinationblockBlob.StartCopyAsync(sourceblockBlob);
        }

        public async Task SetContainerMetadata()
        {

            CloudStorageAccount StorageAccount = StorageConnection.GetAzureConnection();

            CloudBlobClient blobClient = StorageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("images");

            container.Metadata.Add("Application", "App1");


            container.Metadata["Owner"] = "itrain";
            await container.SetMetadataAsync();
        }

        public void GenerateSAS()
        {
            var sasPolicy = new SharedAccessBlobPolicy()
        {
            Permissions = SharedAccessBlobPermissions.Read,
            SharedAccessStartTime = DateTime.Now.AddMinutes(-1),
            SharedAccessExpiryTime = DateTime.Now.AddMinutes(3)
        };
            string imageToUpload = @"D:\AzureTutorial\Network.png";

            string blobReference = imageToUpload.Split('\\').Last();

            string containerName = "images";

            CloudStorageAccount StorageAccount = StorageConnection.GetAzureConnection();

            CloudBlobClient blobClient = StorageAccount.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference(containerName);

            CloudBlockBlob blob = container.GetBlockBlobReference(blobReference);

            string SASToken=blob.GetSharedAccessSignature(sasPolicy);
            string bloburi = blob.StorageUri.PrimaryUri + SASToken;
        }

    }
}

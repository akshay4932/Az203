﻿using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlobTutorial
{
    public class StorageConnection
    { public static CloudStorageAccount GetAzureConnection()
        {
            CloudStorageAccount account = CloudStorageAccount.Parse( CloudConfigurationManager.GetSetting("StorageConnection"));
            return account;
        }
    }
}

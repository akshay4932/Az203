﻿using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Azure_Search.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var searchServiceName = "SearchServiceName";
            var adminApiKey = "SearchServiceAdminApiKey";

            var serviceClient = new SearchServiceClient(searchServiceName, new SearchCredentials(adminApiKey));

            var indexClient = serviceClient.Indexes.GetClient("");

            SearchParameters sp = new SearchParameters() { SearchMode= SearchMode.All };

            var Docs = indexClient.Documents.Search("xyz", sp);
         
            return Json(Docs.Results, JsonRequestBehavior.AllowGet);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
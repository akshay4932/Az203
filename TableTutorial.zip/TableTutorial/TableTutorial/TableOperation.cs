﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableTutorial
{
    public class AzureTableOperation
    {
        public async Task InsertIntoTable()
        {
            StorageConnection connection = new StorageConnection();
            CloudStorageAccount cloudStorageAccount = connection.storageAccount;
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("mytable");
            await table.CreateIfNotExistsAsync();

            ITrain train = new ITrain("Azure", "IaaS")
            {
                CourseFee = 5000,
                Duration = 10,
                TrainerName = "Akshay"
            };

            TableOperation InsertOperation = TableOperation.Insert(train);

            await table.ExecuteAsync(InsertOperation);

        }

        public async Task InsertBatchIntoTable()
        {
            StorageConnection connection = new StorageConnection();
            CloudStorageAccount cloudStorageAccount = connection.storageAccount;
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("mytable");
            await table.CreateIfNotExistsAsync();

            ITrain train = new ITrain("AWS", "Beginners")
            {
                CourseFee = 5000,
                Duration = 20,
                TrainerName = "Akshay"
            };

            ITrain train2 = new ITrain("AWS", "Intermediate")
            {
                CourseFee = 5000,
                Duration = 20,
                TrainerName = "Akshay"
            };
            ITrain train3 = new ITrain("AWS", "Advanced")
            {
                CourseFee = 10000,
                Duration = 40,
                TrainerName = "Akshay"
            };

            TableBatchOperation operations = new TableBatchOperation();

            operations.Insert(train);
            operations.Insert(train2);
            operations.Insert(train3);

            await table.ExecuteBatchAsync(operations);
        }

        public async Task ReadDataFromTable()
        {
            StorageConnection connection = new StorageConnection();
            CloudStorageAccount cloudStorageAccount = connection.storageAccount;
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("mytable");
            TableContinuationToken token = null;
            TableQuery<ITrain> query = new TableQuery<ITrain>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, "AWS"));
            do
            {
                TableQuerySegment<ITrain> q = await table.ExecuteQuerySegmentedAsync(query, token);
                token = q.ContinuationToken;
                foreach (ITrain item in q)
                {

                    Console.WriteLine("Result is {0},{1}\t{2}\t{3}\t{4}", item.PartitionKey, item.RowKey, item.CourseFee, item.Duration, item.TrainerName);
                }
            } while (token != null);
        }

        public async Task ReadSingleEntity()
        {
            StorageConnection connection = new StorageConnection();
            CloudStorageAccount cloudStorageAccount = connection.storageAccount;
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("mytable");

            TableOperation operation = TableOperation.Retrieve<ITrain>("Azure", "IaaS");

            TableResult result = await table.ExecuteAsync(operation);

            ITrain train = (ITrain)result.Result;

            Console.WriteLine(train.TrainerName);
        }

        public async Task UpdateEntity()
        {
            StorageConnection connection = new StorageConnection();
            CloudStorageAccount cloudStorageAccount = connection.storageAccount;
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("mytable");

            TableOperation operation = TableOperation.Retrieve<ITrain>("Azure", "IaaS");

            TableResult r = await table.ExecuteAsync(operation);

            ITrain train = (ITrain)r.Result;

            if (train != null)
            {
                train.TrainerName = "Rajnish";

                TableOperation updateoperation = TableOperation.Replace(train);
                await table.ExecuteAsync(updateoperation);
                Console.WriteLine("Entity Updated");

            }
            else
            {
                Console.WriteLine("Search Entity does not exist");
            }


        }

        public async Task InsertOrUpdateEntity()
        {
            StorageConnection connection = new StorageConnection();
            CloudStorageAccount cloudStorageAccount = connection.storageAccount;
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("mytable");

            ITrain train = new ITrain("C#", "Azure")
            {
                CourseFee = 8000,
                Duration = 30,
                TrainerName = "Ram"
            };


            TableOperation insertoperation = TableOperation.Insert(train);

            await table.ExecuteAsync(insertoperation);

            ITrain train2 = new ITrain("C#", "Azure")
            {
                CourseFee = 18000,
                Duration = 40,
                TrainerName = "Ramesh"
            };

            TableOperation insertOrReplace = TableOperation.InsertOrReplace(train2);
            await table.ExecuteAsync(insertOrReplace);




        }

        public async Task DeleteEntity()
        {
            StorageConnection connection = new StorageConnection();
            CloudStorageAccount cloudStorageAccount = connection.storageAccount;
            CloudTableClient tableClient = cloudStorageAccount.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("mytable");

            TableOperation retrieveOperation = TableOperation.Retrieve<ITrain>("Azure", "70-533");

            // Execute the operation.
            TableResult retrievedResult = table.Execute(retrieveOperation);

            // Assign the result to a CustomerEntity.
            ITrain deleteEntity = (ITrain)retrievedResult.Result;

            // Create the Delete TableOperation.
            if (deleteEntity != null)
            {
                TableOperation deleteOperation = TableOperation.Delete(deleteEntity);

                // Execute the operation.
                await table.ExecuteAsync(deleteOperation);

                Console.WriteLine("Entity deleted.");
            }
            else
            {
                Console.WriteLine("Could not retrieve the entity.");
            }
        }
    }
}

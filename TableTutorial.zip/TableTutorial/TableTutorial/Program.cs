﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableTutorial
{
    class Program
    {
        static void Main(string[] args)
        {
            AzureTableOperation tableOperation = new AzureTableOperation();
            //tableOperation.InsertIntoTable().Wait();
            //tableOperation.InsertBatchIntoTable().Wait();
            //tableOperation.ReadDataFromTable().Wait();
            //tableOperation.ReadSingleEntity().Wait();
            //tableOperation.UpdateEntity().Wait();
            tableOperation.InsertOrUpdateEntity().Wait();
            //tableOperation.DeleteEntity().Wait();
            Console.ReadLine();
        }
    }
}

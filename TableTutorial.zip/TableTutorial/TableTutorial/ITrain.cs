﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableTutorial
{
    public class ITrain :TableEntity
    {
        public ITrain(string technologyName, string courseName)
        {
            this.PartitionKey = technologyName;
            this.RowKey = courseName;
        }
        public ITrain()
        {

        }

        public int CourseFee { get; set; }

        public int Duration { get; set; }

        public string TrainerName { get; set; }


    }
}
